#include <kipr/botball.h>
#include "lego.h"
#include "create_main.h"
#include "utilities.h"
#include "create.h"

int main()
{
    //lego_main();
    create_main();

    return 0;
}
